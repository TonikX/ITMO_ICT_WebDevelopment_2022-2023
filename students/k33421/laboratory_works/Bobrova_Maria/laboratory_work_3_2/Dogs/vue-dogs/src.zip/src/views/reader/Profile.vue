<template>
<div>
    <div
      elevation="2"
      outlined
      class="my-2"
    >
      <div>
        <h2>Личный кабинет</h2>
      </div>

      <div>
        <div class="text--primary">
          <!--Кличка: <b>{{ this.reader.name }}</b> <br>-->
          <!--Логин: {{ this.reader.login }} <br>-->
          <!--Порода: {{ this.reader.breed }} <br>
          Возраст: {{ this.reader.age }} <br>
          Родословная: {{ this.reader.family }} <br>
          Адрес: {{ this.reader.address }} <br>
          Телефон: {{ this.reader.phone_number }} <br>-->
        </div>
      </div>
      <br>
      <h3>Форма регистрации вашей собаки</h3>  
     <form @submit.prevent="signDogs"> <!-- исправить файл-->

      <div class="row">
        <div class="col-25">
          <label for="fname">Кличка</label>
        </div>
        <div class="col-75">
          <input v-model="name" type="text" id="fname" name="name" placeholder="Кличка">
        </div>
      </div>

      <div class="row">
        <div class="col-25">
          <label for="breed">Порода</label>
        </div>
        <div class="col-75">
          <select v-model="breed" id="breed" name="breed">
            <option value="h">h</option>
            <option value="t">t</option>
            <option value="b">b</option>
          </select>
        </div>
      </div>

      <div class="row">
        <div class="col-25">
          <label for="age">Возраст</label>
        </div>
        <div class="col-75">
          <input v-model="age" id="age" name="age" placeholder="Возраст">
        </div>
      </div>

      <div class="row">
        <div class="col-25">
          <label for="family">Родословная</label>
        </div>
        <div class="col-75">
          <textarea v-model="family" id="family" name="family" placeholder="Родословная"></textarea>
        </div>
      </div>

      <div class="row">
        <div class="col-25">
          <label for="owner_data">Данные хозяина</label>
        </div>
        <div class="col-75">
          <textarea v-model="owner_data" id="owner_data" name="owner_data" placeholder="Данные хозяина"></textarea>
        </div>
      </div>

      <button type="submit">Зарегистрировать</button>

  </form>
    </div>
  <br>
  <!--<v-card
    elevation="2"
    outlined
    class="my-2">
    <v-card-text class="text--primary">
      Вы сейчас читаете:
      <ul>
          <li v-for="instance in reader.instances_on_hands" v-bind:key="instance" v-bind:instance="instance">
            <a @click.prevent="goBook(instance.id)">{{ instance.book.book_name }}</a>, {{ instance.book.author }}
          </li>
        </ul>
    </v-card-text>
  </v-card>
  -->
  <!--<div>
    <div  style="margin-top:1cm">
      <a @click.prevent="goEdit">Редактировать профиль</a><br>
    </div>
  </div>-->

    <div>
      <div style="margin-top:1cm">
        <!--<a @click.prevent="goCatalogue">Каталог</a><br>-->
        <a @click.prevent="goHome">На главную</a>
      </div>
    </div>
  </div>
</template>

<script>
import $ from "jquery";
export default {
  name: 'Profile',

  data () {
    return {
      //participant: Object,
      name: '',
      breed: '',
      age: Number,
      family: '',
      owner_data: '',
      //club
    }
  },

  // created () {
  //   this.loadReaderData()
  // },

  methods: {
    async signDogs () {
      
      $.ajax({
                type: "POST",
                data: {
                        name: this.name,
                        breed: this.breed,
                        age: this.age,
                        family: this.family,
                        owner_data: this.owner_data
                },
                url: "http://127.0.0.1:8000/participants/"
            }).done(function () {
                console.log(this.data)
                //this.$router.push({ name: 'participants' }) //сделать Participants.vue
            });
    },
    // async loadReaderData () {
    //   const response = await this.axios
    //     .get('http://127.0.0.1:8000/auth/users/me/', {
    //       headers: {
    //         Authorization: `Token ${localStorage.getItem('auth_token')}`
    //       }
    //     })
    //   this.reader = response.data
    //   await this.loadCurrentlyReading()
    // },

    // async loadCurrentlyReading () {
    //   this.cur_read_url = 'http://127.0.0.1:8000/participants/' + this.reader.id
    //   const response = await this.axios.get(this.cur_read_url)
    //   this.reader = response.data
    //   console.log('hehe ' + this.reader.phone_number)
    // },

    //goBook (bookID) {
    //  this.$router.push({ name: 'instance', params: { id: bookID } }) 
    //},

    //goCatalogue () {
    //  this.$router.push({ name: 'catalogue' })
    //},

    goHome () {
      this.$router.push({ name: 'home' })
    },

    //goEdit () {
      //this.$router.push({ name: 'profile_edit' })
    //}
  }
}
</script>

<style>

</style>
